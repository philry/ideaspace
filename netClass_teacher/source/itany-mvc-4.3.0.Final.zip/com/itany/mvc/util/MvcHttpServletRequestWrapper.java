package com.itany.mvc.util;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class MvcHttpServletRequestWrapper
	extends HttpServletRequestWrapper{
	
	private HttpServletRequest request;
	
	private Map<String, String[]> paramMap = new HashMap<String, String[]>();

	public MvcHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);
		this.request = request;
		this.paramMap.putAll(request.getParameterMap()); 
	}
	
	public void setParameter(String paramName,String paramValue)
	{
		String[] arr = paramMap.get(paramName);
		if(arr == null)
		{
			arr = new String[]{paramValue};
			paramMap.put(paramName, arr);
			return;
		}
		
		String[] newArr = new String[arr.length + 1];
		System.arraycopy(arr, 0, newArr, 0, arr.length);
		newArr[arr.length] = paramValue;
		paramMap.put(paramName, newArr);
	}
	
	@Override
	public String getParameter(String name) {
		String[] res = paramMap.get(name);
		if(res == null || res.length == 0)
		{
			return null;
		}
		return res[0];
	}
	
	@Override
	public String[] getParameterValues(String name) {
		return paramMap.get(name);
	}

	@Override
	public Map<String, String[]> getParameterMap() {
		return paramMap;
	}

	@Override
	public HttpServletRequest getRequest() {
		return request;
	}

}
