package com.itany.mvc.util;

import java.lang.reflect.Method;

/**
 * 
 * <请求处理方法映射对象>
 *  
 * @author  崔译
 * @version  [V1.00, 2018-1-5]
 * @see  [相关类/方法]
 * @since V1.00
 */
public class HandlerMapping {
	
	/**
	 * 方法所在类的对象
	 */
	private Object obj;
	/**
	 * 方法对象
	 */
	private Method method;

	public HandlerMapping() {
	}

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}

	public Method getMethod() {
		return method;
	}

	public void setMethod(Method method) {
		this.method = method;
	}

	public HandlerMapping(Object obj, Method method) {
		this.obj = obj;
		this.method = method;
	}
	
	
}
