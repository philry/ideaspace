package com.itany.mvc.config;

public abstract class WebConfigurer {

	public abstract void addViewControllers(ResourceHandlerRegistry registry);
	
}
