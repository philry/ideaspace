package com.itany.mvc.config;

import java.util.HashMap;
import java.util.Map;

public class ResourceHandlerRegistry {
	
	private Map<String, String> mappings = new HashMap<String, String>();
	
	public ResourceHandlerRegistry addViewController(String viewName,String url)
	{
		mappings.put(url, viewName);
		return this;
	}

	public boolean contains(String url) {
		return mappings.containsKey(url);
	}

	public String get(String url) {
		return mappings.get(url);
	}
	
	public Map<String, String> getViewControllers() {
		return mappings;
	}

}
